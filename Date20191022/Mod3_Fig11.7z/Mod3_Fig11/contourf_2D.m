clc;
clear;
Data_par1= load('OutputParameters1.txt');
xn1=Data_par1(1);
zn1=Data_par1(2);
Grid_spa1=Data_par1(3);           %�ȼ��

x1=linspace(0,(xn1-1)*Grid_spa1,xn1);          % ����ͼ�λ��ƴ�С
z1=linspace(0,(zn1-1)*Grid_spa1,zn1);
[X1,Z1]=meshgrid(x1,z1);
%====================================================================
Data_par2= load('OutputParameters2.txt');
xn2=Data_par2(1);
zn2=Data_par2(2);
Grid_spa2=Data_par2(3);           %�ȼ��

x2=linspace(0,(xn2-1)*Grid_spa2,xn2);          % ����ͼ�λ��ƴ�С
z2=linspace(0,(zn2-1)*Grid_spa2,zn2);
[X2,Z2]=meshgrid(x2,z2);
%====================================================================
Data_Mod = load('Mod_y4_slice.txt');            %   �ٶ�ģ�Ͷ�ȡ
Data_Tim0 = load('Tim_y4_slice.txt');           %   ��ʱ��ȡ
Data_Tim1 = load('Tim_y1_slice.txt');           %   ��ʱ��ȡ
Data_Tim2 = load('2D_timeFSM2.txt');            %   ��ʱ��ȡ
Data_TimSph = load('Data_Shp_Car.txt');         %   ��ʱ��ȡ

%====================================================================
imagesc(x2,z2,Data_Mod);
mim1=min(min(Data_Mod));max1=max(max(Data_Mod));caxis([mim1*0.9 max1*1.1]);
h=colorbar;
set(get(h,'Title'),'string','km/s','fontname','Times New Roman','FontSize',14);
hold on;
%====================================================================
v=linspace(0,0.2*30,31);        % ���õ�ֵ�߼��

contour(X2,Z2,Data_Tim0,v,'r','LineWidth',1.0);  % �����������ʱ
contour(X1,Z1,Data_Tim1,v,'m','LineWidth',1.0);  % ԭģ����ʱ
contour(X1,Z1,Data_Tim2,v,'y','LineWidth',1.0);  % ԭģ����ʱ

contour(X2,Z2,Data_TimSph,v,'b','LineWidth',1.0);  % ��������ʱ,'LineWidth',
[c,h]=contour(X2,Z2,Data_TimSph,v,'--k','LineWidth',1.0);  % ��������ʱ,'LineWidth',1
clabel(c,h,'LabelSpacing',1000,'fontsize',3,'color','k') 

set(gca,'FontSize',12)
%====================================================================
legend('Cartesian coordinates FSM0','Cartesian coordinates FSM1','Cartesian coordinates FSM2','Spherical coordinates FMM','Spherical coordinates FSM')      % �ȸ���ͼ��
axis equal; axis tight;          % xy��ȼ��
set(legend,'FontSize',10); 
set(gca,'xaxislocation','top','yaxislocation','left','ydir','reverse') % set origin position 
xlabel('x-distance (km) ','fontname','Times New Roman','Color','k','FontSize',14)
ylabel('z-depth(km) ','fontname','Times New Roman','Color','k','FontSize',14)
set(gcf,'Position',[200 350 855 400]);
hold off;